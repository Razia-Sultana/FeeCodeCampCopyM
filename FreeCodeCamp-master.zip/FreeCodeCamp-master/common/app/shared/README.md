Here is where all components that are shared between multiple views
