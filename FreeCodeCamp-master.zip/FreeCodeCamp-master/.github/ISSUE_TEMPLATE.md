<!-- FreeCodeCamp Issue Template -->

<!-- NOTE: ISSUES ARE NOT FOR CODE HELP - Ask for Help at https://gitter.im/FreeCodeCamp/Help -->
<!-- Please provide as much detail as possible for us to fix your issue -->
<!-- Remove any heading sections you did not fill out -->

#### Challenge Name
<!-- Insert link to challenge below -->


#### Issue Description
<!-- Describe below when the issue happens and how to reproduce it -->


#### Browser Information
<!-- Describe your workspace in which you are having issues-->

* Browser Name, Version: 
* Operating System: 
* Mobile, Desktop, or Tablet: 

#### Your Code

```js
// If relevant, paste all of your challenge code in here

```

#### Screenshot
<!-- Add a screenshot of your issue -->


